package router

type RouterGroup struct {
	EmailRouter
}

var RouterGroupApp = new(RouterGroup)
