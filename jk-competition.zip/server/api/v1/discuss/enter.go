package discuss

type ApiGroup struct {
	DisInfoApi
}
