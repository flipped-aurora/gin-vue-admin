package response

type SysAuthorityBtnRes struct {
	Selected []uint `json:"selected"`
}
