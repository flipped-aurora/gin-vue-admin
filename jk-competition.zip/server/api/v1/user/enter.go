package user

type ApiGroup struct {
	UserInfoApi
}
