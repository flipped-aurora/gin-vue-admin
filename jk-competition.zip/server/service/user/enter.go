package user

type ServiceGroup struct {
	UserInfoService
}
