package comment

type ApiGroup struct {
	CommentInfoApi
}
