package comment

type ServiceGroup struct {
	CommentInfoService
}
