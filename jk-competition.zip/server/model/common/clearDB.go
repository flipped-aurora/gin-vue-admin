package common

type ClearDB struct {
	TableName    string
	CompareField string
	Interval     string
}
