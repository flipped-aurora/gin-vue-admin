package competitionInfo

type RouterGroup struct {
}
