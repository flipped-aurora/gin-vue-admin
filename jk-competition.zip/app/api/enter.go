package api

var U UserInfoApi
var C ComInfoApi
var D DisInfoApi
var CC CommentInfoApi
