package competition

type ServiceGroup struct {
	ComInfoService
}
