package competition

type ApiGroup struct {
	ComInfoApi
}
