package discuss

type RouterGroup struct {
	DisInfoRouter
}
