package user

type RouterGroup struct {
	UserInfoRouter
}
