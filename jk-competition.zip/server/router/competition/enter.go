package competition

type RouterGroup struct {
	ComInfoRouter
}
