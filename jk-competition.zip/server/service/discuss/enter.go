package discuss

type ServiceGroup struct {
	DisInfoService
}
