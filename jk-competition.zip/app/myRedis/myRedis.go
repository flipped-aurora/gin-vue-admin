package myRedis

//
//import (
//	"encoding/json"
//	"fmt"
//
//
//	"github.com/redis/go-redis/v9"
//	"time"
//)

//var RD *redis.Client
//
//func init() {
//
//}
//func Get(key string) (interface{}, error) {
//	return RD.Do("get", key)
//}
//func Set(key string, value interface{}, expiration time.Duration) (reply interface{}, err error) {
//	fmt.Printf("set %s,%s", va)
//	datas, _ := json.Marshal(value)
//	return RD.Do("set", key, datas)
//}
//func GetStructVal(st *interface{}, key string) error {
//	rebytes, err := redis.Bytes(RD.Do("get", key))
//	if err != nil {
//		return err
//	}
//	err = json.Unmarshal(rebytes, st)
//	if err != nil {
//		return err
//	}
//	return nil
//}
